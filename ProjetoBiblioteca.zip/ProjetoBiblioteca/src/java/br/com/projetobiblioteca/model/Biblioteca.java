package br.com.projetobiblioteca.model;

public class Biblioteca {
    private int idBiblioteca;
    private String nomeBiblioteca;
    private String cidadeBiblioteca;
    private String estadoBiblioteca;
    private String cepBiblioteca;
    private String enderecoBiblioteca;

    public Biblioteca() {
    }

    public Biblioteca(int idBiblioteca, String nomeBiblioteca, String cidadeBiblioteca, String estadoBiblioteca, String cepBiblioteca, String enderecoBiblioteca) {
        this.idBiblioteca = idBiblioteca;
        this.nomeBiblioteca = nomeBiblioteca;
        this.cidadeBiblioteca = cidadeBiblioteca;
        this.estadoBiblioteca = estadoBiblioteca;
        this.cepBiblioteca = cepBiblioteca;
        this.enderecoBiblioteca = enderecoBiblioteca;
    }

    public int getIdBiblioteca() {
        return idBiblioteca;
    }

    public void setIdBiblioteca(int idBiblioteca) {
        this.idBiblioteca = idBiblioteca;
    }

    public String getNomeBiblioteca() {
        return nomeBiblioteca;
    }

    public void setNomeBiblioteca(String nomeBiblioteca) {
        this.nomeBiblioteca = nomeBiblioteca;
    }

    public String getCidadeBiblioteca() {
        return cidadeBiblioteca;
    }

    public void setCidadeBiblioteca(String cidadeBiblioteca) {
        this.cidadeBiblioteca = cidadeBiblioteca;
    }

    public String getEstadoBiblioteca() {
        return estadoBiblioteca;
    }

    public void setEstadoBiblioteca(String estadoBiblioteca) {
        this.estadoBiblioteca = estadoBiblioteca;
    }

    public String getCepBiblioteca() {
        return cepBiblioteca;
    }

    public void setCepBiblioteca(String cepBiblioteca) {
        this.cepBiblioteca = cepBiblioteca;
    }

    public String getEnderecoBiblioteca() {
        return enderecoBiblioteca;
    }

    public void setEnderecoBiblioteca(String enderecoBiblioteca) {
        this.enderecoBiblioteca = enderecoBiblioteca;
    }
   
}
