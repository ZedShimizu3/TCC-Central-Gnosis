package br.com.projetobiblioteca.model;

public class Usuario extends Pessoa {
    
    private int idUsuario;
    private String nickUsuario;

    public Usuario() {
    }

    public Usuario(int idUsuario, String nickUsuario) {
        this.idUsuario = idUsuario;
        this.nickUsuario = nickUsuario;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getNickUsuario() {
        return nickUsuario;
    }

    public void setNickUsuario(String nickUsuario) {
        this.nickUsuario = nickUsuario;
    }
    
}
