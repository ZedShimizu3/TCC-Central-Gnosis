package br.com.projetobiblioteca.dao;
import br.com.projetobiblioteca.model.Usuario;
import br.com.projetobiblioteca.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAOImpl implements GenericDAO{

    private Connection conn;

    public UsuarioDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
            System.out.println("Conectado com sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }
    
    @Override
    public Boolean cadastrar(Object object) {

        Usuario usuario = (Usuario) object;
        PreparedStatement stmt = null;

        String sql = "Insert into usuario(nickusuario, idpessoa) values (?, ?);";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, usuario.getNickUsuario());
            stmt.setInt(2, new PessoaDAOImpl().cadastrar(usuario));
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar usuario! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }
    
    public Object logarUsuario(String email, String senha){
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Usuario usuario = null;
        String sql = "select * from pessoa where emailpessoa = ? and senhapessoa = ?;";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, senha);
            rs = stmt.executeQuery();
            while (rs.next()) {
                usuario = new Usuario();
                usuario.setEmailPessoa(rs.getString("emailpessoa"));
                usuario.setSenhaPessoa(rs.getString("senhapessoa"));
            }
        } catch (SQLException ex) {
            System.out.println("Problemas ao listar usuarios! Erro:" + ex.getMessage());
            ex.printStackTrace();

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro" + e.getMessage());
                e.printStackTrace();
            }
        }
        return usuario;
    }
    
    @Override
    public List<Object> listar() {
        List<Object> usuarios = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Usuario usuario = null;

        String sql = "select u.*, p.* from usuario u, pessoa p where p.idpessoa = u.idpessoa and u.idpessoa = ?;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                usuario = new Usuario();
                usuario.setIdUsuario(rs.getInt("idusuario"));
                usuario.setNickUsuario(rs.getString("nickusuario"));
                usuario.setNomePessoa(rs.getString("nomepessoa"));
                usuario.setTelefonePessoa(rs.getString("telefonepessoa"));
                usuario.setCpfPessoa(rs.getString("cpfpessoa"));
                usuario.setEmailPessoa(rs.getString("emailpessoa"));
                usuario.setSenhaPessoa(rs.getString("senhapessoa"));
                usuario.setIdPessoa(rs.getInt("idpessoa"));
                usuarios.add(usuario);
            }
        } catch (SQLException ex) {
            System.out.println("Problemas ao listar usuario! Erro:" + ex.getMessage());
            ex.printStackTrace();

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro" + e.getMessage());
                e.printStackTrace();
            }
        }
        return usuarios;
    }

    @Override
    public Boolean excluir(int idOject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Usuario usuario = null;
        String sql = "select p.*, u.* from pessoa p, usuario u where p.idpessoa = u.idpessoa and u.idpessoa = ?;";
        try {
            stmt = conn.prepareStatement (sql);
            stmt.setInt(1, idObject);
            rs = stmt.executeQuery();
	
            while (rs.next()) {
		usuario = new Usuario();
                usuario.setIdUsuario(rs.getInt("idusuario"));
		usuario.setNickUsuario(rs.getString("nickusuario"));
		usuario.setTelefonePessoa(rs.getString("telefonepessoa"));
                usuario.setCpfPessoa(rs.getString("cpfpessoa"));
                usuario.setEmailPessoa(rs.getString("emailpessoa"));
                usuario.setIdPessoa(rs.getInt("idpessoa"));
            }
        } catch (SQLException ex) {
            System.out.println("Problemas ao carregar usuario! Erro:" + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro" + e.getMessage());
                e.printStackTrace();
            }
        }
        return usuario;
    }

    @Override
    public Boolean alterar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
