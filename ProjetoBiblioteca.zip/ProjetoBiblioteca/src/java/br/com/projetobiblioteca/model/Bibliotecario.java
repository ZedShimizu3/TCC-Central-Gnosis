
package br.com.projetobiblioteca.model;


public class Bibliotecario extends Pessoa {
    
    private int idBibliotecario;
    private String idadeBibliotecario;

    public Bibliotecario() {
    }

    public Bibliotecario(int idBibliotecario, String idadeBibliotecario) {
        this.idBibliotecario = idBibliotecario;
        this.idadeBibliotecario = idadeBibliotecario;
    }

    public int getIdBibliotecario() {
        return idBibliotecario;
    }

    public void setIdBibliotecario(int idBibliotecario) {
        this.idBibliotecario = idBibliotecario;
    }

    public String getIdadeBibliotecario() {
        return idadeBibliotecario;
    }

    public void setIdadeBibliotecario(String idadeBibliotecario) {
        this.idadeBibliotecario = idadeBibliotecario;
    }
    
    
}
